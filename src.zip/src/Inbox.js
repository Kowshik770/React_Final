import React, { Component } from 'react'
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import CardGroup from 'react-bootstrap/CardGroup';
import {Link} from 'react-router-dom';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import Form from 'react-bootstrap/Form'; 
import Table from 'react-bootstrap/Table';







export default class Inbox extends Component {
  constructor(props){
    super(props);
    
   this.state={
     leave:{}
 
}

this.ShowSpecificLeave=this.ShowSpecificLeave.bind(this);
    
}
logout(){
  sessionStorage.clear();
  alert('signout')
  window.location="/"

}

ShowSpecificLeave(e){
    
    let leaveId=this.state.leaveId;
    let employeeId=localStorage.getItem("empid");
    console.log(employeeId)
    axios.get("http://localhost:22452/api/Employee/"+employeeId)
    .then(response=>{
      this.setState({leave:response.data})

  }).catch(error=>{
      console.warn(error)
  })
  
}



//  testing grid select



    render() {
        let UserName=localStorage.getItem("empname");
        
        return (<>
          
          <header>
          <h1>Employee Dashboard</h1>
              <label for="check">
                  <svg xmlns="http://www.w3.org/2000/svg" width="40" height="50" fill="currentColor" class="bi bi-justify" id="sidebar_btn" viewBox="0 0 16 16">
    <path fill-rule="evenodd" d="M2 12.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"/>
                  </svg>
              </label>
              <div ><h3>welcome {UserName}</h3></div>
              <div>
                  <button onClick={this.logout} >Logout </button>
        </div>
        </header>
     
      <div  class="sidebar">
          <a href="GetEmployeeDetails" ><span>Details</span></a>&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="GetEmployeeLeaveDetails"><span>EmployeeLeaveDetails</span></a>&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="UpdateEmployeeDetails"><span>Update Details</span></a>&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="ApplyNewLeaveForEmployee"><span>New Leave Application</span></a> &nbsp;&nbsp;&nbsp;&nbsp; 
          <a href=" GetManagerDetails"><span>My Manager Details</span></a>  
          </div>
          <div class="content"></div>
          </>
        )
    }
}